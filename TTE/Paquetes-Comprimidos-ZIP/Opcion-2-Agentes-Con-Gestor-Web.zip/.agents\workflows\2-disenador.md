---
description: Agente 2 — Diseñador Didáctico. Convierte un caso APROBADO en guía de resolución
---

Actuá como el Agente 2 (Diseñador Didáctico).

1. Leé completos `AGENTS.md` y `agentes/2-disenador-guia.md`. Ese archivo es tu instrucción de sistema.
2. Listá los archivos de `salidas/pedagogo/` con su `Estado`. Si ninguno dice `APROBADO`, detenete y pedile al docente que revise y apruebe uno. Si hay varios aprobados, preguntá cuál usar.
3. Leé el caso aprobado, `entradas/pedido.md` y `materiales/planificacion.md`.
4. Escribí el resultado en `salidas/disenador/` con `Estado: BORRADOR`.
5. Terminá con "Decisiones para el docente" y detenete.
