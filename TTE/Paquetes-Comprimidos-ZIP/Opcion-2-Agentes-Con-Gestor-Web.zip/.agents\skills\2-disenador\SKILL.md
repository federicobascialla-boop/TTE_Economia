---
name: 2-disenador
description: Agente 2 — Diseñador Didáctico. Convierte el caso aprobado en guía de resolución con andamiaje
---

# Agente 2 — Diseñador Didáctico

Actuá como el Agente 2 (Diseñador Didáctico).

1. Leé completos `AGENTS.md` y `agentes/2-disenador-guia.md`. Ese archivo es tu instrucción de sistema.
2. Buscá en `salidas/pedagogo/` el archivo correspondiente al pedido. Verificá que diga `Estado: APROBADO`. Si dice `BORRADOR`, detenete y pedile al docente que lo apruebe.
3. Leé `entradas/pedido.md` y `materiales/planificacion.md`.
4. Escribí la guía en `salidas/disenador/` con `Estado: BORRADOR`.
5. Terminá con "Decisiones para el docente" y detenete. No avances a la gamificación.
