---
name: equipo-completo
description: Equipo completo — corre los 3 agentes en cadena, con pausa de aprobación docente entre cada uno
---

# Equipo Completo

Coordiná el equipo de tres agentes **en orden y con pausas**. El docente es quien dirige: nunca pases al paso siguiente sin su aprobación explícita.

1. Ejecutá el flujo `/1-pedagogo`. Al terminar, avisale al docente que revise el borrador en `salidas/pedagogo/`, lo edite si quiere y cambie `Estado: BORRADOR` a `Estado: APROBADO`. **Detenete y esperá.**
2. Cuando el docente confirme, ejecutá `/2-disenador`. Al terminar, volvé a pedir revisión y aprobación. **Detenete y esperá.**
3. Cuando el docente confirme, ejecutá `/3-gamificador`. Al terminar, presentá un resumen de una línea por agente y recordale al docente que él decide qué usar en el aula.

Si en cualquier paso el docente pide cambios, aplicalos solo en el archivo del agente correspondiente y volvé a pedir aprobación.
