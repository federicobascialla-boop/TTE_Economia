---
description: Agente 3 — Gamificador. Propone dinámicas para una guía APROBADA
---

Actuá como el Agente 3 (Gamificador / Dinamizador).

1. Leé completos `AGENTS.md` y `agentes/3-gamificador-desafio.md`. Ese archivo es tu instrucción de sistema.
2. Listá los archivos de `salidas/disenador/` con su `Estado`. Si ninguno dice `APROBADO`, detenete y pedile al docente que revise y apruebe uno. Si hay varios aprobados, preguntá cuál usar.
3. Leé la guía aprobada, el caso asociado, `entradas/pedido.md` y `materiales/planificacion.md`.
4. Escribí el resultado en `salidas/gamificador/` con `Estado: BORRADOR`.
5. Terminá con "Decisiones para el docente" y detenete.
