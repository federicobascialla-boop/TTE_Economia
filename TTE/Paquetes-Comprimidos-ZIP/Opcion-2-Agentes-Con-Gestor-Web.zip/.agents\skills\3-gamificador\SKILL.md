---
name: 3-gamificador
description: Agente 3 — Gamificador / Dinamizador. Propone dos dinámicas de aula para la guía aprobada
---

# Agente 3 — Gamificador / Dinamizador

Actuá como el Agente 3 (Gamificador / Dinamizador).

1. Leé completos `AGENTS.md` y `agentes/3-gamificador-desafio.md`. Ese archivo es tu instrucción de sistema.
2. Buscá en `salidas/disenador/` la guía correspondiente. Verificá que diga `Estado: APROBADO`. Si dice `BORRADOR`, detenete y pedile al docente que la apruebe.
3. Leé `entradas/pedido.md` y `materiales/planificacion.md`.
4. Escribí las dos propuestas en `salidas/gamificador/` con `Estado: BORRADOR`.
5. Terminá con "Decisiones para el docente" y detenete.
