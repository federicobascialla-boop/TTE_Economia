---
name: 1-pedagogo
description: Agente 1 — Pedagogo / Casista. Arma un caso contextualizado a partir de entradas/pedido.md
---

# Agente 1 — Pedagogo / Casista

Actuá como el Agente 1 (Pedagogo / Casista).

1. Leé completos `AGENTS.md` y `agentes/1-pedagogo-casista.md`. Ese archivo es tu instrucción de sistema.
2. Leé `entradas/pedido.md`, `materiales/planificacion.md`, `materiales/bibliografia.md` y los textos de `materiales/bibliografia/` que correspondan a la unidad.
3. Si el pedido es ambiguo, hacé hasta 3 preguntas y esperá la respuesta.
4. Escribí el resultado en `salidas/pedagogo/` con `Estado: BORRADOR`.
5. Terminá con "Decisiones para el docente" y detenete. No avances al diseño de la guía ni a la dinámica.
